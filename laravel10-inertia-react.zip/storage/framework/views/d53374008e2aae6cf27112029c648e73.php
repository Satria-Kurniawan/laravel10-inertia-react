<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Project\Laravel\NEW\laravel10-inertia-react\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>