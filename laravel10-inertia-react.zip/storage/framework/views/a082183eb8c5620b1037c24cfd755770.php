<?php echo e($slot); ?>

<?php /**PATH D:\Project\Laravel\NEW\laravel10-inertia-react\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>