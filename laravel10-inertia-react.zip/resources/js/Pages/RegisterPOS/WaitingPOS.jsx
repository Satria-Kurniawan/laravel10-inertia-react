const WaitingPOS = () => {
    return <div>WaitingPOS</div>;
};

export default WaitingPOS;
