import { Link } from "@inertiajs/react";
import { useState } from "react";

import { MdSpaceDashboard } from "react-icons/md";
import {
    FaStore,
    FaShoppingBag,
    FaHistory,
    FaSignOutAlt,
} from "react-icons/fa";
import { IoMdSettings } from "react-icons/io";

const Sidebar = (props) => {
    const [isOpen, setIsOpen] = useState(true);

    const { pathname } = window.location;

    const links = [
        {
            icon: <MdSpaceDashboard />,
            name: "Dashboard",
            path: "/admin/dashboard",
        },
        { icon: <FaStore />, name: "Store", path: "/admin/store" },
        { icon: <FaShoppingBag />, name: "Cashier", path: "/admin/cashier" },
        { icon: <FaHistory />, name: "History", path: "/admin/history" },
        { icon: <IoMdSettings />, name: "Settings", path: "/admin/settings" },
    ];

    return (
        <aside
            className={`${
                isOpen ? "w-64" : "w-24"
            } p-7 h-screen sticky top-0 overflow-hidden duration-500`}
        >
            <div className="px-2 inline-flex gap-x-3 items-center">
                <button
                    onClick={() => setIsOpen(!isOpen)}
                    className={`${
                        isOpen && "rotate-[360deg]"
                    } w-8 h-8 flex justify-center items-center duration-500 delay-500`}
                >
                    <div className="flex flex-col gap-y-1">
                        <div
                            className={`${
                                isOpen ? "w-6" : "w-[20px]"
                            } h-[2px] bg-white duration-500`}
                        />
                        <div className="h-[2px] w-6 bg-white duration-500" />
                        <div
                            className={`${
                                isOpen ? "w-6" : "w-[14px]"
                            } h-[2px] bg-white duration-500`}
                        />
                    </div>
                </button>
                <h1
                    className={`${
                        isOpen ? "opacity-100" : "opacity-0 -translate-x-5"
                    } font-bold text-xl origin-left duration-500`}
                >
                    BrandName
                </h1>
            </div>
            <ul className="mt-7 flex flex-col gap-y-5">
                {links.map((link, i) => (
                    <Link
                        key={i}
                        href={link.path}
                        className={`${
                            isOpen && "hover:bg-tertiary"
                        } py-1 px-2 inline-flex gap-x-3 items-center rounded-md duration-300`}
                    >
                        <div
                            className={`${
                                pathname === link.path
                                    ? "bg-primary text-black"
                                    : "bg-tertiary"
                            } p-[6px] rounded-md text-xl duration-300 ${
                                !isOpen && "hover:bg-primary hover:text-black"
                            }`}
                        >
                            {link.icon}
                        </div>
                        <span
                            className={`${
                                isOpen
                                    ? "opacity-100"
                                    : "opacity-0 -translate-x-5"
                            } origin-left duration-300`}
                        >
                            {link.name}
                        </span>
                    </Link>
                ))}
            </ul>
            <div className="absolute bottom-5">
                <Link
                    href={route("logout")}
                    method="post"
                    as="button"
                    className={`${
                        isOpen && "bg-tertiary hover:bg-danger group"
                    } py-1 px-2 w-full inline-flex gap-x-3 items-center rounded-md duration-500`}
                >
                    <div
                        className={`p-[6px] bg-tertiary rounded-md text-xl hover:bg-danger group-hover:bg-danger duration-500`}
                    >
                        <FaSignOutAlt />
                    </div>
                    <span
                        className={`${
                            isOpen ? "opacity-100" : "opacity-0 -translate-x-5"
                        } bg-tertiary group-hover:bg-danger origin-left duration-500`}
                    >
                        Sign Out
                    </span>
                </Link>
                <h6 className="mt-5 text-sm">&#169;2023 Point of Sales</h6>
            </div>
        </aside>
    );
};

export default Sidebar;
